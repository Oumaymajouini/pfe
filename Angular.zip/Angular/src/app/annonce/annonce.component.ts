import { Annonce } from './../annonce';
import { Localisation } from './../localisation';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, Inject, OnInit } from '@angular/core';
import { AnnonceserviceService } from 'src/Services/annonceservice.service';
import { HttpResponse, HttpEventType } from '@angular/common/http';
import {  FormControl, ReactiveFormsModule }from '@angular/forms';
import { Router } from '@angular/router';
import {MatDialog, MatDialogConfig, MAT_DIALOG_DATA,MatDialogRef } from '@angular/material/dialog';
import { CategorieServiceService } from 'src/Services/categorie-service.service';


@Component({
  selector: 'app-annonce',
  templateUrl: './annonce.component.html',
  styleUrls: ['./annonce.component.css']
})
export class AnnonceComponent implements OnInit {
  userFile: any ;

  // annoncee:Annonce={};
  public imagePath: any;
  imgURL: any;
  public Category : any;
  public listannonce : Array<Annonce>=[];
  public CategorieList : any;
  public LocalisationList : any;
  loc: Localisation = new Localisation();
  annonce: Annonce = new Annonce();
  // localisationDto:Localisation={};

  event:any;
  public message!: string;
   constructor(public service:AnnonceserviceService,public _service : CategorieServiceService,private  formBuilder : FormBuilder, private router : Router,@Inject(MAT_DIALOG_DATA)  public data:any,
   ) { }
   get f() { return this.service.dataForm.controls; }
  ngOnInit(): void {
this._service.getAllAdress()
    .subscribe(res=>{
      this.LocalisationList = res;


    });

//     this.service.getAll().subscribe(res=>{
// this.listannonce=res;


//     });
        this._service.getAll()
    .subscribe(res=>{
      this.CategorieList = res;


    });
    this.service.dataForm=this.formBuilder.group({

      categorie : ['',Validators.required],

      date : ['',Validators.required],
      prix : ['',Validators.required],
      description : ['',Validators.required]

    })
    this.service.getCategorie()

    .subscribe(res=>{

      this.Category = res;



    });
  }



  registerAnnonce(){
    const formData = new  FormData();
    const annonce = this.service.dataForm.value;
    formData.append('annonce',JSON.stringify(annonce));
    formData.append('file',this.userFile);
    this.annonce.localisation = this.loc;
    // this.annoncee.localisation=this.localisationDto;
if (this.service.dataForm.valid){
    this.service.createData(formData)
    .subscribe({
      next:(res)=>{
        alert("annonce ajouté avec succée")
        console.log(annonce);

      },
      error:()=>{
        alert("error")
      }
    }

    );

  }
}

onSelectFile(event:any) {
  if (event.target.files.length > 0)
  {
    const file = event.target.files[0];
    this.userFile = file;
   // this.f['profile'].setValue(file);

  var mimeType = event.target.files[0].type;
  if (mimeType.match(/image\/*/) == null) {
    this.message = "Only images are supported.";
    return;
  }

  var reader = new FileReader();

  this.imagePath = file;
  reader.readAsDataURL(file);
  reader.onload = (_event) => {
    this.imgURL = reader.result;
  }
}


  }
}
