import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AnnonceserviceService } from 'src/Services/annonceservice.service';
import { Annonce } from '../annonce';

@Component({
  selector: 'app-contactuser',
  templateUrl: './contactuser.component.html',
  styleUrls: ['./contactuser.component.css']
})
export class ContactuserComponent implements OnInit {
  public filterCategory : any;

  annonceId!:any;
  annonce!: Annonce;
  constructor(public service:AnnonceserviceService,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.annonceId = this.route.snapshot.params['annonceId'];
    this.service.getannonce(this.annonceId)
     .subscribe(data => {
       console.log(data)
       // this.annonce = data;
       this.filterCategory = data;
     },
     error => console.log(error));
  }

}
