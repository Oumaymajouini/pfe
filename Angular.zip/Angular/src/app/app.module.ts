import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { AproposComponent } from './apropos/apropos.component';

import { ContactComponent } from './contact/contact.component';
import { CopyrightComponent } from './copyright/copyright.component';
import { ConnexionComponent } from './connexion/connexion.component';
import { InscriptionComponent } from './inscription/inscription.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';

import { PhotoComponent } from './photo/photo.component';
import { AnnonceComponent } from './annonce/annonce.component';
import { ListannonceComponent } from './listannonce/listannonce.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



import { EditprofileComponent } from './editprofile/editprofile.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpEventType } from '@angular/common/http';

import { UserListComponent } from './user-list/user-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import {MatButtonModule} from '@angular/material/button';
import {MatDialogModule} from '@angular/material/dialog';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
import {MatSelectModule} from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';

import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { SidenavComponent } from './sidenav/sidenav.component';
import { HeaderComponent } from './header/header.component';

import { UpdateUserComponent } from './update-user/update-user.component';

import { DashbProfessionnelComponent } from './dashb-professionnel/dashb-professionnel.component';

import { DashbClientComponent } from './dashb/dashb-client.component';
import { ReclammationComponent } from './reclammation/reclammation.component';
import { ReclamationListComponent } from './reclamation-list/reclamation-list.component';
import { EspacepersonnelComponent } from './espacepersonnel/espacepersonnel.component';
import { FilterPipe } from './filter.pipe';
import { AnnoncesAdminComponent } from './annonces-admin/annonces-admin.component';
import { ChoixInscriptionComponent } from './choix-inscription/choix-inscription.component';
import { InscriptionProfessionnelComponent } from './inscription-professionnel/inscription-professionnel.component';
import { ListUserbloquesComponent } from './list-userbloques/list-userbloques.component';
import { ListAnnoncesProfComponent } from './list-annonces-prof/list-annonces-prof.component';

import { MesannoncesComponent } from './mesannonces/mesannonces.component';
import { AutreCategoriesComponent } from './autre-categories/autre-categories.component';
import { VosannoncesComponent } from './vosannonces/vosannonces.component';
import { SignalerAnnonceComponent } from './signaler-annonce/signaler-annonce.component';
import { ContactuserComponent } from './contactuser/contactuser.component';



@NgModule({
  declarations: [
    AppComponent,
    AproposComponent,

    ContactComponent,
    CopyrightComponent,
    ConnexionComponent,
    InscriptionComponent,
    NavbarComponent,
    HomeComponent,

    PhotoComponent,
    AnnonceComponent,
    ListannonceComponent,


    EditprofileComponent,


    UserListComponent,
    DashboardComponent,
    SidenavComponent,
    HeaderComponent,
    UpdateUserComponent,
     DashbClientComponent,
     DashbProfessionnelComponent,
     ReclammationComponent,
      ReclamationListComponent,
      EspacepersonnelComponent,
      FilterPipe,
      AnnoncesAdminComponent,
      ChoixInscriptionComponent,
      InscriptionProfessionnelComponent,
      ListUserbloquesComponent,
      ListAnnoncesProfComponent,

      MesannoncesComponent,
      AutreCategoriesComponent,
      VosannoncesComponent,
      SignalerAnnonceComponent,
      ContactuserComponent,









  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    CarouselModule,

    MatButtonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,


    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    FormsModule,
    MatSidenavModule,
    MatToolbarModule,
    MatMenuModule,
    MatDividerModule,
    MatListModule,
  ],


  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
