import { ComponentFixture } from '@angular/core/testing';

import { InscriptionComponent } from './inscription/inscription.component';
import { ContactComponent } from './contact/contact.component';

import { AproposComponent } from './apropos/apropos.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConnexionComponent } from './connexion/connexion.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';

import { PhotoComponent } from './photo/photo.component';
import { AnnonceComponent } from './annonce/annonce.component';
import { ListannonceComponent } from './listannonce/listannonce.component';

import { EditprofileComponent } from './editprofile/editprofile.component';


import { UserListComponent } from './user-list/user-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { UpdateUserComponent } from './update-user/update-user.component';

import { DashbProfessionnelComponent } from './dashb-professionnel/dashb-professionnel.component';
import { DashbClientComponent } from './dashb/dashb-client.component';
import { ReclammationComponent } from './reclammation/reclammation.component';
import { ReclamationListComponent } from './reclamation-list/reclamation-list.component';
import { EspacepersonnelComponent } from './espacepersonnel/espacepersonnel.component';
import { AnnoncesAdminComponent } from './annonces-admin/annonces-admin.component';
import { ChoixInscriptionComponent } from './choix-inscription/choix-inscription.component';
import { InscriptionProfessionnelComponent } from './inscription-professionnel/inscription-professionnel.component';
import { ListUserbloquesComponent } from './list-userbloques/list-userbloques.component';
import { ListAnnoncesProfComponent } from './list-annonces-prof/list-annonces-prof.component';

import { MesannoncesComponent } from './mesannonces/mesannonces.component';
// import { AutreCategoriesComponent } from './autre-categories/autre-categories.component';
import { VosannoncesComponent } from './vosannonces/vosannonces.component';
import { SignalerAnnonceComponent } from './signaler-annonce/signaler-annonce.component';
import { ContactuserComponent } from './contactuser/contactuser.component';
import { AutreCategoriesComponent } from './autre-categories/autre-categories.component';

const routes: Routes = [

  {path:"apropos",component:AproposComponent},

  {path:"contact",component:ContactComponent},
  {path:"inscription",component:InscriptionComponent},
  {path:'connexion',component:ConnexionComponent},
  {path:'navbar',component:NavbarComponent},
  {path:'home',component:HomeComponent},
  {path:'',component:HomeComponent},


  {path:'photo',component:PhotoComponent},
  {path:'annonce',component:AnnonceComponent},
  {path:'listannonce',component:ListannonceComponent},

  {path:'editprofile',component:EditprofileComponent},

  {path:'listuser',component:UserListComponent},
  {path:'listreclamation',component:ReclamationListComponent},
  {path:'dashboard',component:DashboardComponent},
  {path:'dashclient',component:DashbClientComponent},
  {path:'dashprof',component:DashbProfessionnelComponent},
  {path:'reclammation',component:ReclammationComponent},
  {path:'espace',component:EspacepersonnelComponent},

  {path:'',redirectTo:'profile',pathMatch:'full'},
  {path:'update/:userId',component:UpdateUserComponent},
  {path:'annonceAdmin',component:AnnoncesAdminComponent},
  {path:'choix',component:ChoixInscriptionComponent},
  {path:'inscriprof',component:InscriptionProfessionnelComponent},
  {path:'listuserbloque',component:ListUserbloquesComponent},
  {path:'listannoncespro',component:ListAnnoncesProfComponent},

  {path:'vosannonces',component:VosannoncesComponent},
  {path:'annoncedetails/:annonceId',component:MesannoncesComponent},
  {path:'autres',component:AutreCategoriesComponent},
  {path:'signaler',component:SignalerAnnonceComponent},
  {path:'contactuser',component:ContactuserComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
