import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashbProfessionnelComponent } from './dashb-professionnel.component';

describe('DashbProfessionnelComponent', () => {
  let component: DashbProfessionnelComponent;
  let fixture: ComponentFixture<DashbProfessionnelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashbProfessionnelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashbProfessionnelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
