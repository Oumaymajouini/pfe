import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { InscriptionService } from 'src/Services/inscription.service';
import { UserserviceService } from 'src/Services/userservice.service';
import { ReclammationComponent } from '../reclammation/reclammation.component';
import { User } from '../user';
@Component({
  selector: 'app-dashb-professionnel',
  templateUrl: './dashb-professionnel.component.html',
  styleUrls: ['./dashb-professionnel.component.css']
})
export class DashbProfessionnelComponent implements OnInit {
  name!: string | null;

  title = 'admin-panel-layout';
  sideBarOpen = true;
  id!:any;
  user=new User;
  sideBarToggler() {
    this.sideBarOpen = !this.sideBarOpen;
  }
  constructor(private dialog :MatDialog,private router:Router,public _service:UserserviceService,public service:InscriptionService,private  formBuilder : FormBuilder) { }

  ngOnInit(): void {

    this.id=localStorage.getItem('id');
    this.name=localStorage.getItem('name');
  }
  openDialog3() {
    this.dialog.open(ReclammationComponent, {
      width:'25%'
    });
  }

  updateProfile(){
    this._service.getUser(this.id).subscribe(
      data=> {
        this.user=data;
        this._service.dataForm=this.formBuilder.group(Object.assign({},this.user));
        this.router.navigate(['/editprofile']);
      },
      error=>console.log(error));

  }
}
