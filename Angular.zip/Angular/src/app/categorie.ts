export class Categorie {
  categorieId!: number;
  code!: string;
  libelle!: string;

}
