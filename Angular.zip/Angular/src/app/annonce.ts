import { Localisation } from './localisation';

export class Annonce {
  annonceId!: number;
  categorie!: string;
  localisation?: Localisation ;
  prix!: string;
  date!:Date;
  image!: string;
  description!: string;



}

