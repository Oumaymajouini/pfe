import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AnnonceserviceService } from 'src/Services/annonceservice.service';
import { Annonce } from '../annonce';

@Component({
  selector: 'app-annonces-admin',
  templateUrl: './annonces-admin.component.html',
  styleUrls: ['./annonces-admin.component.css']
})
export class AnnoncesAdminComponent implements OnInit {

  filterCategory!: Observable<Annonce[]>;

  public productList : any ;
  constructor(public service:AnnonceserviceService) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.filterCategory = this.service.getAnnonce();
  }
  deleteAnnonce(AnnonceId: number) {
    this.service.deleteAnnonce(AnnonceId)
      .subscribe(
        data => {
        alert('Annonce supprimé avec succée ');
        },
        error =>  {alert ('echec');}
      );
  }
}
