import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { InscriptionService } from 'src/Services/inscription.service';
import { MatDialog,MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../user';
import { UserserviceService } from 'src/Services/userservice.service';
@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {
  userFile: any ;
  public message!: string;
  hide = true;
  userId!: number;
  user!: User;
  public imagePath: any;
  imgURL: any;
  id!:any;
  constructor(private route: ActivatedRoute,private router: Router,
    private userService: UserserviceService,public service:InscriptionService,private  formBuilder : FormBuilder) { }
    get f() { return this.service.dataForm.controls; }
  ngOnInit() {
    this.id=localStorage.getItem('id');
    this.user = new User();

     this.userService.getUser(this.id)
      .subscribe(data => {
        console.log(data)
        this.user = data;
      }, error => console.log(error));

      // this.service.dataForm=this.formBuilder.group({
      //   username : ['',Validators.required],
      //   email : ['',Validators.required],
      //   dateNaissance : ['',Validators.required],
      //   telephone : ['',Validators.required],
      //   adresse : ['',Validators.required],
      //   password : ['',Validators.required],

      // })

    }

    onSubmit() {
      this.userService.updateUser(this.user)

        .subscribe(data =>
          alert("  Modification effectué avec succée"),
         error => console.log(error));
      this.user = new User();

      }


      // updateData(){
      //   const formData = new  FormData();
      //   const users = this.service.dataForm.value;
      //   formData.append('user',JSON.stringify(users));
      //   formData.append('file',this.userFile);
      //   this.service.updatedata(this.service.dataForm.value.id,formData);
      //   alert("  Modification effectué avec succée");
      // }


      onSelectFile(event:any) {
        if (event.target.files.length > 0)
        {
          const file = event.target.files[0];
          this.userFile = file;
         // this.f['profile'].setValue(file);

        var mimeType = event.target.files[0].type;
        if (mimeType.match(/image\/*/) == null) {
          this.message = "Only images are supported.";
          return;
        }

        // var reader = new FileReader();

        // this.imagePath = file;
        // reader.readAsDataURL(file);
        // reader.onload = (_event) => {
        //   this.imgURL = reader.result;
        // }
      }


        }
  }




