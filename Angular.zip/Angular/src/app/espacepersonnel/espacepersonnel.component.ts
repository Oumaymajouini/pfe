import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-espacepersonnel',
  templateUrl: './espacepersonnel.component.html',
  styleUrls: ['./espacepersonnel.component.css']
})
export class EspacepersonnelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
