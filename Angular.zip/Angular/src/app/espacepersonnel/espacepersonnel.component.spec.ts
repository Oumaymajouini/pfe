import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EspacepersonnelComponent } from './espacepersonnel.component';

describe('EspacepersonnelComponent', () => {
  let component: EspacepersonnelComponent;
  let fixture: ComponentFixture<EspacepersonnelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EspacepersonnelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EspacepersonnelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
