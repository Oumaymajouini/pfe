import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { InscriptionService } from 'src/Services/inscription.service';
import {MatDialog, MatDialogConfig, MAT_DIALOG_DATA,MatDialogRef } from '@angular/material/dialog';
import { User } from './../user';
import { UserserviceService } from 'src/Services/userservice.service';

@Component({
  selector: 'app-inscription',
  templateUrl: './inscription.component.html',
  styleUrls: ['./inscription.component.css']
})
export class InscriptionComponent implements OnInit {
  inscriptionForm !: FormGroup;
  hide = true;
  user = new User();
  userFile: any ;
  public imagePath: any;
  imgURL: any;
  public message!: string;
  event:any;


  constructor(public service:InscriptionService,public _service: UserserviceService ,private  formBuilder : FormBuilder, private router : Router,@Inject(MAT_DIALOG_DATA)  public data:any,) { }
  get f() { return this.service.dataForm.controls; }
  ngOnInit(): void {
    this.service.dataForm=this.formBuilder.group({
      username : ['',Validators.required],
      email : ['',Validators.required],
      dateNaissance : ['',Validators.required],
      telephone : ['',Validators.required],
      adresse : ['',Validators.required],
      password : ['',Validators.required],
      role : ['Client',Validators.required],
      etat : ['non bloqué',Validators.required],


    })



  }



  registerUser(){
    const formData = new  FormData();
    const user = this.service.dataForm.value;
    formData.append('user',JSON.stringify(user));
    formData.append('file',this.userFile);
    if (this.service.dataForm.valid){
      this.service.createData(formData)
      .subscribe({
        next:(res)=>{
          alert("vous êtes inscrit avec succée ")
        },
        error:()=>{
          alert("error")
        }
      }
      );
    }
    }
updateData(){
  const formData = new  FormData();
  const users = this.service.dataForm.value;
  formData.append('user',JSON.stringify(users));
  formData.append('file',this.userFile);
  this.service.updatedata(this.service.dataForm.value.userID,formData).subscribe(data=>{
    this._service.getUtilisateursList().subscribe(

    response=>{this._service.list=response;}

    );
  })

}

    onSelectFile(event:any) {
      if (event.target.files.length > 0)
      {
        const file = event.target.files[0];
        this.userFile = file;
       // this.f['profile'].setValue(file);

      var mimeType = event.target.files[0].type;
      if (mimeType.match(/image\/*/) == null) {
        this.message = "Only images are supported.";
        return;
      }

      var reader = new FileReader();

      this.imagePath = file;
      reader.readAsDataURL(file);
      reader.onload = (_event) => {
        this.imgURL = reader.result;
      }
    }


      }
}
