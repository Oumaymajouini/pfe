import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { UserserviceService } from 'src/Services/userservice.service';
import { User } from '../user';

@Component({
  selector: 'app-list-userbloques',
  templateUrl: './list-userbloques.component.html',
  styleUrls: ['./list-userbloques.component.css']
})
export class ListUserbloquesComponent implements OnInit {
  utilisateurs!: Observable<User[]>;
  user = new User();
  constructor(private userservice:UserserviceService) { }

  ngOnInit(){
    this.reloadData();
  }
  reloadData() {
     this.utilisateurs = this.userservice.getUtilisateursetatList("bloqué");

  }
  changerEtat(userId: number) {
    this.userservice.updateEtat(userId)
      .subscribe(
        data => {
        alert(' Vous avez débloquer utilisateur ');
        },
        error =>  {alert ('echec');}
      );
  }
}




