import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListUserbloquesComponent } from './list-userbloques.component';

describe('ListUserbloquesComponent', () => {
  let component: ListUserbloquesComponent;
  let fixture: ComponentFixture<ListUserbloquesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListUserbloquesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListUserbloquesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
