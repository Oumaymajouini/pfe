import { Observable } from 'rxjs';
import { Annonce } from './annonce';


export class Localisation {
  localisationId!: number;
  libelle!: string;
  ListAnnonces!: Observable<Annonce>;
}
