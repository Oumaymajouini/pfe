import { Annonce } from './annonce';

describe('Annonce', () => {
  it('should create an instance', () => {
    expect(new Annonce()).toBeTruthy();
  });
});
