import { Component, EventEmitter, OnInit, Output} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { InscriptionService } from 'src/Services/inscription.service';
import { UserserviceService } from 'src/Services/userservice.service';
import { EditprofileComponent } from '../editprofile/editprofile.component';
import { UpdateUserComponent } from '../update-user/update-user.component';
import { User } from '../user';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  name!: string | null;
  id!:any;

  user=new User();
  @Output() toggleSidebarForMe: EventEmitter<any> = new EventEmitter();
  constructor(private router: Router,public service:InscriptionService,private dialog :MatDialog,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.name=localStorage.getItem('name');
    this.id=localStorage.getItem('id');
  }
  toggleSidebar() {
    this.toggleSidebarForMe.emit();
  }
   openDialog3(){
    this.dialog.open(EditprofileComponent, {
      width:'40%',
      height:'100%',


    });

  }
}
