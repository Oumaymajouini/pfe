
import { ReclammationComponent } from './../reclammation/reclammation.component';
import { Component, OnInit } from '@angular/core';
import { AnnonceComponent } from '../annonce/annonce.component';
import {MatDialog} from '@angular/material/dialog';
import { InscriptionService } from 'src/Services/inscription.service';

import { Observable } from 'rxjs';
import { User } from '../user';
import { UserserviceService } from 'src/Services/userservice.service';
import { EditprofileComponent } from '../editprofile/editprofile.component';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashb-client',
  templateUrl: './dashb-client.component.html',
  styleUrls: ['./dashb-client.component.css']
})
export class DashbClientComponent implements OnInit {
  title = 'admin-panel-layout';
  sideBarOpen = true;
user=new User;
name!: string | null;
id!:any;


  sideBarToggler() {
    this.sideBarOpen = !this.sideBarOpen;
  }
  constructor(private dialog :MatDialog,private router:Router,public service:InscriptionService,public _service:UserserviceService,private  formBuilder : FormBuilder) { }

  ngOnInit():void {
    this.name=localStorage.getItem('name');

    this.id=localStorage.getItem('id');
  }

  updateProfile(){
    this._service.getUser(this.id).subscribe(
      data=> {
        this.user=data;
        this._service.dataForm=this.formBuilder.group(Object.assign({},this.user));
        this.router.navigate(['/editprofile']);
      },
      error=>console.log(error));

  }


  openDialog() {
    this.dialog.open(AnnonceComponent, {
      width:'50%'
    });
  }

  openDialog2() {
    this.dialog.open(ReclammationComponent, {
      width:'25%'
    });
  }
}
