import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashbClientComponent } from './dashb-client.component';

describe('DashbClientComponent', () => {
  let component: DashbClientComponent;
  let fixture: ComponentFixture<DashbClientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashbClientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashbClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
