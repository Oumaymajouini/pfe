
import { Userauth } from './../Model/auth.model';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { Route, Router } from '@angular/router';

import { InscriptionService } from '../../Services/inscription.service';
import { User } from '../user';


@Component({
  selector: 'app-connexion',
  templateUrl: './connexion.component.html',
  styleUrls: ['./connexion.component.css']
})
export class ConnexionComponent implements OnInit {
  loginForm !: FormGroup;
  // title = 'Angular Upload Files';
  user = new User();
  msg = '';
  state: boolean = false;
  passwordType: string = 'password';
  erreur = 0;


  constructor(private _service: InscriptionService, private _router: Router, private formBuilder: FormBuilder) { }

  public toggle() {
    if (this.state) {
      this.state = false;
      this.passwordType = 'password';
    }
    else {
      this.state = true;
      this.passwordType = 'text';
    }
  }

  ngOnInit() {
    this._service.islogin = false;
    this._service.admin = false;
    this._service.client = false;
    this._service.professionnel = false;




  }
  loginUser() {
    this._service.loginUserFromRemote(this.user).subscribe(
      response => {
        this.user = response;

       localStorage.setItem("name",this.user.username);
       localStorage.setItem('id',JSON.stringify(this.user.userId));
       localStorage.setItem("rolee",this.user.role);
      //  localStorage.setItem("annonce",this.user.annonces);

        if (this.user.etat == "non bloqué") {
          if (this.user.role == "Admin") {
            this._service.admin = true;
            this._router.navigate(['/dashboard']);


          }
          else if (this.user.role == "Client") {
            this._service.client = true;
            this._router.navigate(['/dashclient']);
            // console.log(this.user);
          }



          else  {
            this._service.professionnel = true;
            this._router.navigate(['/dashprof']);
          }

        }
          else {
            this.erreur = 2;


          }




      },
      error => {

        this.erreur = 1;
      }


    )


  }

}











// onLoggedin(){

//   // console.log(this.user);
//   let isValidUser:Boolean=this._service.loginUserFromRemote(this.user);
//   if (isValidUser)
//   this._router.navigate(['/dashboard']);
//   else
//   this.erreur=1;
// }

