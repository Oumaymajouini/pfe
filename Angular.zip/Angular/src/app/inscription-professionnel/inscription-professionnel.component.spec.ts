import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InscriptionProfessionnelComponent } from './inscription-professionnel.component';

describe('InscriptionProfessionnelComponent', () => {
  let component: InscriptionProfessionnelComponent;
  let fixture: ComponentFixture<InscriptionProfessionnelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InscriptionProfessionnelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InscriptionProfessionnelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
