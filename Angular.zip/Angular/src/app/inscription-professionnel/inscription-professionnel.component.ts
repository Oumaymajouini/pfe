import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { InscriptionService } from 'src/Services/inscription.service';
import {MatDialog, MatDialogConfig, MAT_DIALOG_DATA,MatDialogRef } from '@angular/material/dialog';
import { User } from './../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inscription-professionnel',
  templateUrl: './inscription-professionnel.component.html',
  styleUrls: ['./inscription-professionnel.component.css']
})
export class InscriptionProfessionnelComponent implements OnInit {
  inscriptionForm !: FormGroup;
  hide = true;
  user = new User();
  userFile: any ;
  public imagePath: any;
  imgURL: any;
  public message!: string;
  event:any;
  constructor(public  service:InscriptionService,private  formBuilder : FormBuilder, private router : Router,@Inject(MAT_DIALOG_DATA)  public data:any,) { }
  get f() { return this.service.dataForm.controls; }
  ngOnInit(): void {
    this.service.dataForm=this.formBuilder.group({
      username : ['',Validators.required],
      email : ['',Validators.required],
      dateNaissance : ['',Validators.required],
      telephone : ['',Validators.required],
      profile : ['',Validators.required],
      adresse : ['',Validators.required],
      password : ['',Validators.required],
      role : ['Professionnel',Validators.required],
      etat : ['non bloqué',Validators.required],
    })

}
registerUser(){
  const formData = new  FormData();
    const user = this.service.dataForm.value;
    formData.append('user',JSON.stringify(user));
    formData.append('file',this.userFile);
  if (this.service.dataForm.valid){
    this.service.createData(formData)
    .subscribe({
      next:(res)=>{
        alert("vous êtes inscrit avec succée ")
      },
      error:()=>{
        alert("error")
      }
    }
    );

  }
  }

  onSelectFile(event:any) {
    if (event.target.files.length > 0)
    {
      const file = event.target.files[0];
      this.userFile = file;
     // this.f['profile'].setValue(file);

    var mimeType = event.target.files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }

    var reader = new FileReader();

    this.imagePath = file;
    reader.readAsDataURL(file);
    reader.onload = (_event) => {
      this.imgURL = reader.result;
    }
  }


    }

}
