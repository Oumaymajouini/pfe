import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListAnnoncesProfComponent } from './list-annonces-prof.component';

describe('ListAnnoncesProfComponent', () => {
  let component: ListAnnoncesProfComponent;
  let fixture: ComponentFixture<ListAnnoncesProfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListAnnoncesProfComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListAnnoncesProfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
