import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { InscriptionProfessionnelComponent } from '../inscription-professionnel/inscription-professionnel.component';
import { InscriptionComponent } from '../inscription/inscription.component';

@Component({
  selector: 'app-choix-inscription',
  templateUrl: './choix-inscription.component.html',
  styleUrls: ['./choix-inscription.component.css']
})
export class ChoixInscriptionComponent implements OnInit {

  constructor(private dialog :MatDialog) { }

  ngOnInit(): void {
  }
  openDialog(){
    this.dialog.open(InscriptionComponent, {
      width:'50%',

    });

  }
  openDialog1(){
    this.dialog.open(InscriptionProfessionnelComponent, {
      width:'50%',

    });

  }
}
