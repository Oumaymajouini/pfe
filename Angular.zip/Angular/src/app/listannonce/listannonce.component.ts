import { Annonce } from './../annonce';
import { Component, OnInit } from '@angular/core';
import { AnnonceserviceService } from 'src/Services/annonceservice.service';
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listannonce',
  templateUrl: './listannonce.component.html',
  styleUrls: ['./listannonce.component.css']
})
export class ListannonceComponent implements OnInit {
  searchKey:string ="";
  public searchTerm !: string;
  public filterCategory : any;
  public productList : any ;
  user = new User();
  annonce = new Annonce();
  isRated=false;


  constructor(public service:AnnonceserviceService,private router:Router) {}


  changeRating(){
    this.isRated=!this.isRated;
  }

  ngOnInit(): void {



    this.service.getAnnonce()
    .subscribe(res=>{
      this.productList = res;
      this.filterCategory = res;
      console.log(this.productList)

    });

    this.service.search.subscribe((val:any)=>{
      this.searchKey = val;
    })


  }

  details(annonceId: number){
    this.router.navigate(['annoncedetails', annonceId]);
  }
  search(event:any){
    this.searchTerm = (event.target as HTMLInputElement).value;
    console.log(this.searchTerm);
    this.service.search.next(this.searchTerm);
  }

  filter(categorie:string){
    this.filterCategory = this.productList
    .filter((a:any)=>{
      if(a.categorie == categorie || categorie==''){
        return a;
      }
    })
}




}
function likeTheButton() {
  throw new Error('Function not implemented.');
}

