import { Route, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AnnonceserviceService } from 'src/Services/annonceservice.service';

@Component({
  selector: 'app-autre-categories',
  templateUrl: './autre-categories.component.html',
  styleUrls: ['./autre-categories.component.css']
})
export class AutreCategoriesComponent implements OnInit {
  public filterCategory : any;
  public productList : any ;
  searchKey:string ="";
  public searchTerm !: string;
  constructor(public service:AnnonceserviceService,private router:Router) { }

  ngOnInit(): void {
    this.service.getAnnonce()
    .subscribe(res=>{
      this.productList = res;
      this.filterCategory = res;
      console.log(this.productList)

    });

    this.service.search.subscribe((val:any)=>{
      this.searchKey = val;
    })
  }

  search(event:any){
    this.searchTerm = (event.target as HTMLInputElement).value;
    console.log(this.searchTerm);
    this.service.search.next(this.searchTerm);
  }
  filter(categorie:string){
    this.filterCategory = this.productList
    .filter((a:any)=>{
      if(a.categorie == categorie || categorie==''){
        return a;
      }
    })
}
details(annonceId: number){
  this.router.navigate(['annoncedetails', annonceId]);
}
}
